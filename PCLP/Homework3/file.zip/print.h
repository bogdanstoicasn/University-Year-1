#define NMAX 50
struct global_image;
void file_printer_for_tests(int *type,char file[NMAX],struct global_image image);
