
#define NMAX 50

void counter_clockwise_rotation_90(struct global_image *image,int x1,int y1,int x2,int y2);
void clockwise_rotation_90(struct global_image *image,int x1,int y1,int x2,int y2);
void rotate_function_helper(struct global_image *image,int angle,int x1,int y1,int x2,int y2);
